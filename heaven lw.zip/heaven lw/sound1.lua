local g_VGuiSurface = ffi.cast(ffi.typeof("void***"), utils.create_interface("vguimatsurface.dll", "VGUI_Surface031"))

-- play sound when hit.
local play_sound = ffi.cast(ffi.typeof('void(__thiscall*)(void*, const char*)'), g_VGuiSurface[0][82])

-- custom hitsound.
local function custom_hitsound(event)
    local attacker = event:get_int("attacker")
    local attacker_idx = engine.get_player_for_user_id(attacker)

    if attacker_idx ~= engine.get_local_player_index() then
        return
    end

    play_sound(g_VGuiSurface, "1.wav")
end

-- register event.
events.register_event("player_hurt", custom_hitsound)