menu.add_check_box("LOGS ENABLE")
menu.add_color_picker("Logs's Color")
menu.add_slider_int("Log scale", 10, 40 )
menu.add_color_picker("Logwatermark's color")
local log_messages = {}
local hitlog_font = render.create_font("Smallest Pixel-7", 11, 150, true, true, true)





-- functions
local function custom_colors()
    if menu.get_bool("LOGS ENABLE") then
        local color = menu.get_color("Logs's Color")
        r = color:r()
        g = color:g()
        b = color:b()
        local color2 = menu.get_color("Logwatermark's color")
        r2 = color2:r()
        g2 = color2:g()
        b2 = color2:b()

    end
end

function register_message(text)
    table.insert(log_messages, {message = text, alpha = 0, creation_time = globals.get_realtime()})
end






local function shot_for_event_logs(shot_info)
    local result = shot_info.result

    local gpinf = engine.get_player_info
    local target = shot_info.target_index
    local target_name = gpinf(target).name

    if result == "Hit" then
        local message = " hit player " .. target_name .. " 's ".. shot_info.server_hitbox .. " for " .. shot_info.server_damage .. " hp (predicted: ".. shot_info.client_hitbox .. " for " .. shot_info.client_damage .. " hp)"

        register_message(message)

    elseif result == "Resolver" then
        register_message(" missed shot at " ..  target_name .. "due to desync [ backtrack: " .. shot_info.backtrack_ticks .. " ticks]")
    else
        register_message(" missed shot at ".. target_name .. " due to spread [accuracy: ".. shot_info.hitchance .."]")
    end

end




local function draw_event_logs()
    local screen_width = engine.get_screen_width()
    local screen_height = engine.get_screen_height()

    local distance_to_add = 0
    local last_render_position = 10
    local timeNow = globals.get_realtime()
    custom_colors()
    for i = 1, #log_messages
    do
        if not(log_messages[i] == nil) then
            if(log_messages[i].creation_time > timeNow) or  (log_messages[i].alpha <= 0 and timeNow - log_messages[i].creation_time > 2) then
                table.remove(log_messages, i)
            else
                if(i >= 15) then
                    log_messages[i].creation_time = timeNow
                end

                if(log_messages[i].alpha < 255) and (timeNow - log_messages[i].creation_time < 5) and (i < 15) then
                    log_messages[i].alpha = log_messages[i].alpha + 5
                end

                if(timeNow - log_messages[i].creation_time > 5) and (log_messages[i].alpha > 0) then
                    log_messages[i].alpha = log_messages[i].alpha - 5
                end

                if(log_messages[i].alpha > 0) then

                    local text_size = render.get_text_width( hitlog_font, log_messages[i].message )

                    local distance_modifier = log_messages[i].alpha / 255

                    render.draw_text( hitlog_font, screen_width/2 - 200 , screen_height/2 + last_render_position + distance_to_add + 200, color.new(r, g, b, log_messages[i].alpha), log_messages[i].message )
                    render.draw_text( hitlog_font, screen_width/2 - 240 , screen_height/2 + last_render_position + distance_to_add + 200, color.new(r2,g2, b2, log_messages[i].alpha), "[Legendware]")



                    last_render_position = last_render_position + distance_to_add
                    distance_to_add = menu.get_int("Log scale") * distance_modifier

                end

            end
        end
    end
end





client.add_callback("on_paint", draw_event_logs)
client.add_callback("on_shot", shot_for_event_logs)