--shit paste

local font = render.create_font( "Verdana", 25, 562, true, true, false )
local color0 = color.new(132, 195, 16)
local color1 = color.new(16, 125, 255)
local color2 = color.new(255, 255, 255)
local x, y = engine.get_screen_width() / 115 , engine.get_screen_height() / 1.60

local function indicators()
    local is_ingame = engine.is_in_game()
    local dt = menu.get_key_bind_state( "rage.double_tap_key" )
    local fd = menu.get_key_bind_state( "anti_aim.fake_duck_key" )
    local dmg = menu.get_key_bind_state( "rage.force_damage_key" )
    local hs = menu.get_key_bind_state( "rage.hide_shots_key" )
    local ap = menu.get_key_bind_state( "misc.automatic_peek_key" )
	local f = menu.get_bool("anti_aim.enable_fake_lag")

    if is_ingame then
        local lp = entitylist.get_local_player()
        local lp_health  = lp:get_health()
        if lp_health > 0 then

            if dt then
                space1 = 25
                render.draw_text( font, x, y, color2, "DT" )
            else
                space1 = 0
            end
            if hs then 
                space2 = 25
                render.draw_text( font, x, y + space1, color0, "ONSHOT" )
            else
                space2 = 0
            end
            if dmg then
                space3 = 25
                render.draw_text( font, x, y + space1 + space2, color2, "DMG" )
            else
                space3 = 0
            end
            if fd then
                space4 = 25
                render.draw_text( font, x, y + space1 + space2 + space3, color2, "DUCK" )
            else
                space4 = 0
            end
            if ap then
                space5 = 25
                render.draw_text( font, x, y + space1 + space2 + space3 + space4, color2, "QUICK-PEEK" )
            else
                space5 = 0
			if f then
                space6 = 25
                render.draw_text( font, x, y + space1 + space2 + space3 + space4 + space5, color0, "DA" )
				space6 = 0
			    end
			end
    	end
    end
end
client.add_callback( "on_paint", indicators )