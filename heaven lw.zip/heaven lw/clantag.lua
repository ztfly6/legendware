menu.add_check_box("clantag")
local ffi = require "ffi"

ffi.cdef[[
    typedef int(__fastcall* clantag_t)(const char*, const char*);
]]
local set_clantag = ffi.cast("clantag_t", utils.find_signature("engine.dll", "53 56 57 8B DA 8B F9 FF 15"))
local old_time = 0
local anim = {

    "⌛",
    "H",
    "He",
    "Hea",
    "Heav",
    "Heave",
    "Heaven",
    "Heave",
    "Heav",
    "Hea",
    "He",
    "H",
    "⌛",
    "L",
    "Le",
    "Leg",
    "Lege",
    "Legen",
    "Legend",
    "Legendw",
    "Legendwa",
    "Legendwar",
    "Legendware",
    "Legendwar",
    "Legendwa",
    "Legendw",
    "Legend",
    "Legen",
    "Lege",
    "Leg",
    "Le",
    "L",
    "⌛",
    "B",
    "BE",
    "BES",
    "BEST",
    "BES",
    "BE",
    "B",
    "⌛",
}
function clan_tag()
  if menu.get_bool("clantag") == true then
    local time = globals.get_curtime()
    local speed = math.floor((time * 2.33)+0.5)
    local local_player = entitylist.get_local_player()
    if local_player then
      local site = local_player:get_prop_int("CBaseEntity","m_iTeamNum")
      if site ~= 0 then
        if old_time ~= speed and (globals.get_tickcount() % 2) == 1 then
          set_clantag(anim[speed % #anim+2], anim[speed % #anim+2])
          old_time = speed
        end
      end  
    end
  else
    return
  end
end

client.add_callback("on_paint", clan_tag)
